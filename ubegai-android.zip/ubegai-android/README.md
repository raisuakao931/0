# УБЕГАЙ — Android

Сборка APK:
1. Установите Android Studio: https://developer.android.com/studio
2. File -> Open -> выберите эту папку (ubegai-android). Дождитесь Gradle Sync.
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk. Скопируйте на телефон и установите
   (разрешите установку из неизвестных источников).

Игра работает офлайн, в полноэкранном ландшафтном режиме.

## Сборка через GitHub (без Android Studio)
1. Создайте репозиторий на github.com и загрузите в него всё содержимое этой папки
   (включая скрытую папку .github).
2. Откройте вкладку Actions -> Build APK -> дождитесь зелёной галочки (2-5 минут).
3. Откройте завершённый запуск и скачайте архив ubegai-apk внизу страницы (Artifacts).
   Внутри лежит app-debug.apk.
