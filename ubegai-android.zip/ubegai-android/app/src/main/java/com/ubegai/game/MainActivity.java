package com.ubegai.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0c1210"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                if (!HOST.equals(req.getUrl().getHost())) return null;
                return serve(req.getUrl().getPath());
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("https://" + HOST + "/");
        hideSystemUi();
    }

    private WebResourceResponse serve(String path) {
        if (path == null || path.equals("/")) path = "/index.html";
        String rel = path.substring(1);
        boolean hasExt = rel.lastIndexOf('.') > rel.lastIndexOf('/');
        try {
            InputStream in = getAssets().open("www/" + rel);
            return response(rel, in);
        } catch (IOException e) {
            if (!hasExt) {
                try {
                    return response("index.html", getAssets().open("www/index.html"));
                } catch (IOException ignored) { }
            }
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null,
                    new ByteArrayInputStream(new byte[0]));
        }
    }

    private WebResourceResponse response(String name, InputStream in) {
        String mime = "application/octet-stream";
        String n = name.toLowerCase();
        if (n.endsWith(".html")) mime = "text/html";
        else if (n.endsWith(".js") || n.endsWith(".mjs")) mime = "application/javascript";
        else if (n.endsWith(".css")) mime = "text/css";
        else if (n.endsWith(".woff2")) mime = "font/woff2";
        else if (n.endsWith(".woff")) mime = "font/woff";
        else if (n.endsWith(".svg")) mime = "image/svg+xml";
        else if (n.endsWith(".png")) mime = "image/png";
        else if (n.endsWith(".jpg") || n.endsWith(".jpeg")) mime = "image/jpeg";
        else if (n.endsWith(".json") || n.endsWith(".webmanifest")) mime = "application/json";
        return new WebResourceResponse(mime, "utf-8", in);
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
